package com.itsez609.notes;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;

import org.json.JSONObject;

import java.util.Map;

public class Reminders {

    static class Entry {
        long at;
        String title;
        String body;
        String rep;
    }

    private static final String PREFS = "reminders";

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static Entry get(Context c, String id) {
        String raw = prefs(c).getString(id, null);
        if (raw == null) {
            return null;
        }
        try {
            JSONObject o = new JSONObject(raw);
            Entry e = new Entry();
            e.at = o.getLong("at");
            e.title = o.optString("title", "Note");
            e.body = o.optString("body", "");
            e.rep = o.optString("rep", "");
            return e;
        } catch (Exception ex) {
            return null;
        }
    }

    static void put(Context c, String id, Entry e) {
        try {
            JSONObject o = new JSONObject();
            o.put("at", e.at);
            o.put("title", e.title);
            o.put("body", e.body);
            o.put("rep", e.rep);
            prefs(c).edit().putString(id, o.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static long interval(String rep) {
        if ("daily".equals(rep)) {
            return 86400000L;
        }
        if ("weekly".equals(rep)) {
            return 604800000L;
        }
        return 0L;
    }

    static PendingIntent pending(Context c, String id) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.setAction("com.itsez609.notes.REMIND");
        i.setData(Uri.parse("note://reminder/" + id));
        i.putExtra("id", id);
        return PendingIntent.getBroadcast(c, Math.abs(id.hashCode()), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void arm(Context c, String id, long at) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) {
            return;
        }
        PendingIntent pi = pending(c, id);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (SecurityException se) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    static void schedule(Context c, String id, String title, String body, long at, String rep) {
        long iv = interval(rep);
        long now = System.currentTimeMillis();
        if (iv > 0) {
            while (at <= now) {
                at += iv;
            }
        } else if (at <= now) {
            cancel(c, id);
            return;
        }
        Entry e = new Entry();
        e.at = at;
        e.title = title;
        e.body = body;
        e.rep = (rep == null) ? "" : rep;
        put(c, id, e);
        arm(c, id, at);
    }

    static void cancel(Context c, String id) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            am.cancel(pending(c, id));
        }
        prefs(c).edit().remove(id).apply();
    }

    static void afterFire(Context c, String id, Entry e) {
        long iv = interval(e.rep);
        if (iv > 0) {
            long next = e.at + iv;
            long now = System.currentTimeMillis();
            while (next <= now) {
                next += iv;
            }
            e.at = next;
            put(c, id, e);
            arm(c, id, next);
        } else {
            prefs(c).edit().remove(id).apply();
        }
    }

    static void rescheduleAll(Context c) {
        Map<String, ?> all = prefs(c).getAll();
        long now = System.currentTimeMillis();
        for (String id : all.keySet()) {
            Entry e = get(c, id);
            if (e == null) {
                continue;
            }
            long iv = interval(e.rep);
            long at = e.at;
            if (at <= now) {
                if (iv > 0) {
                    while (at <= now) {
                        at += iv;
                    }
                } else {
                    at = now + 3000L;
                }
            }
            e.at = at;
            put(c, id, e);
            arm(c, id, at);
        }
    }
}
