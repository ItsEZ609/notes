package com.itsez609.notes;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private static final String[] KEYS = {"classic", "ruled", "word", "pen", "scribble"};
    private WebView web;
    private boolean pageReady = false;
    private String pendingOpen = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        int first = (mode == Configuration.UI_MODE_NIGHT_YES) ? 0xFF202124 : 0xFFFBBC04;
        applyBars(first);

        web = new WebView(this);
        web.setBackgroundColor(first);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= 29) {
            s.setForceDark(WebSettings.FORCE_DARK_OFF);
        }

        web.addJavascriptInterface(new Bridge(), "NotesAndroid");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                dispatchOpen();
            }
        });

        pendingOpen = noteIdFrom(getIntent());
        web.loadUrl("file:///android_asset/www/index.html");
    }

    private String noteIdFrom(Intent i) {
        if (i == null) {
            return null;
        }
        String id = i.getStringExtra("noteId");
        if (id != null && id.matches("[0-9]+")) {
            return id;
        }
        return null;
    }

    private void dispatchOpen() {
        if (pageReady && pendingOpen != null) {
            String id = pendingOpen;
            pendingOpen = null;
            web.evaluateJavascript("window.__openNote&&window.__openNote('" + id + "')", null);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String id = noteIdFrom(intent);
        if (id != null) {
            pendingOpen = id;
            dispatchOpen();
        }
    }

    private static boolean isLight(int c) {
        double l = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
        return l > 0.6;
    }

    private void applyBars(int color) {
        Window w = getWindow();
        w.setStatusBarColor(color);
        w.setNavigationBarColor(color);
        boolean light = isLight(color);
        View d = w.getDecorView();
        int f = d.getSystemUiVisibility();
        if (light) {
            f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        } else {
            f &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            if (light) {
                f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            } else {
                f &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
        }
        d.setSystemUiVisibility(f);
    }

    private ComponentName aliasFor(String key) {
        String cap = Character.toUpperCase(key.charAt(0)) + key.substring(1);
        return new ComponentName(getPackageName(), "com.itsez609.notes.Icon" + cap);
    }

    private void switchIcon(String selected) {
        boolean valid = false;
        for (String k : KEYS) {
            if (k.equals(selected)) {
                valid = true;
            }
        }
        if (!valid) {
            return;
        }
        PackageManager pm = getPackageManager();
        for (String k : KEYS) {
            if (k.equals(selected)) {
                pm.setComponentEnabledSetting(aliasFor(k),
                        PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
            }
        }
        for (String k : KEYS) {
            if (!k.equals(selected)) {
                pm.setComponentEnabledSetting(aliasFor(k),
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
            }
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){return window.__back?window.__back():false})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if (!"true".equals(value)) {
                            MainActivity.super.onBackPressed();
                        }
                    }
                });
    }

    public class Bridge {
        @JavascriptInterface
        public void setBars(final String hex) {
            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        int c = Color.parseColor(hex);
                        MainActivity.this.applyBars(c);
                        web.setBackgroundColor(c);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void setReminder(String id, String title, String body, double at, String rep) {
            if (id == null || !id.matches("[0-9]+")) {
                return;
            }
            Reminders.schedule(MainActivity.this, id,
                    title == null ? "Note" : title,
                    body == null ? "" : body,
                    (long) at,
                    rep == null ? "" : rep);
        }

        @JavascriptInterface
        public void cancelReminder(String id) {
            if (id == null || !id.matches("[0-9]+")) {
                return;
            }
            Reminders.cancel(MainActivity.this, id);
        }

        @JavascriptInterface
        public boolean canExact() {
            if (Build.VERSION.SDK_INT >= 31) {
                AlarmManager am = (AlarmManager) MainActivity.this.getSystemService(Context.ALARM_SERVICE);
                return am != null && am.canScheduleExactAlarms();
            }
            return true;
        }

        @JavascriptInterface
        public void askNotif() {
            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= 33
                            && MainActivity.this.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED) {
                        MainActivity.this.requestPermissions(
                                new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
                    }
                }
            });
        }

        @JavascriptInterface
        public void openExactAlarmSettings() {
            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= 31) {
                        try {
                            MainActivity.this.startActivity(new Intent(
                                    Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                    Uri.parse("package:" + MainActivity.this.getPackageName())));
                        } catch (Exception ignored) {
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public void setIcon(final String key) {
            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    MainActivity.this.switchIcon(key);
                }
            });
        }
    }
}
